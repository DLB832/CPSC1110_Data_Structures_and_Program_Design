/**
 * @author Derek Campbell
 * @version 9/28/2020
 */

public interface Efficiency {
    double getEfficiency();
}
