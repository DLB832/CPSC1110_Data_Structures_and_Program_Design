/** 
 * The parent class for Lab3. 
 *   @author Derek Campbell
 *   @version 09/11/2020
*/

public class Circuit
{
    
    //resisters should be stored as a double value.
    public double getResistance() 
    {
        //dummy return value.
        return 0;
    }



}